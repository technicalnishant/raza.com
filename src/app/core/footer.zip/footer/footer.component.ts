import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CurrentSetting } from '../models/current-setting';
import { RazaEnvironmentService } from '../services/razaEnvironment.service';
//import { isNullOrUndefined } from 'util';
import { isNullOrUndefined } from "../../shared/utilities";
import { LoginpopupComponent } from '../../core/loginpopup/loginpopup.component';
import { AuthenticationService } from '../../core/services/auth.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  currentYear: any;

  currentSetting$: Subscription;
  currentSetting: CurrentSetting;
  
  
  get contact1800Number(): string {
    let number = '1-(877) 463-4233';
    if (isNullOrUndefined(this.currentSetting)) {
      return number;
    }

    if (this.currentSetting.currentCountryId === 2) {
      number = '1-(800) 550-3501'
    }

    if (this.currentSetting.currentCountryId === 3) {
      number = '+44-(800) 041-8192'
    }

    return number;

  }

  constructor(
    private razaEnvService: RazaEnvironmentService,
    private router: Router,
    public dialog: MatDialog,
    private authService: AuthenticationService,
  ) {
    this.currentYear = new Date().getFullYear();

  }

  ngOnInit() {
    this.currentSetting$ = this.razaEnvService.getCurrentSetting().subscribe(res => {
      this.currentSetting = res;
    });
  }

  scrollToMobileApp() {
    window.scrollTo(1650, 1650);
  }
  
  redirectClick(obj)
  {
    if (this.authService.isAuthenticated()) {
		
       
        this.router.navigate([obj])
       //this.router.navigate(['account/overview'])
      }
      else
      {
      //this.router.navigate(['auth/sign-up']);
      this.dialog.open(LoginpopupComponent, {
     
        data: { slideIndex: obj }
      });
      }
  }
}
