import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndiaUnlimitedComponent } from './india-unlimited.component';

describe('IndiaUnlimitedComponent', () => {
  let component: IndiaUnlimitedComponent;
  let fixture: ComponentFixture<IndiaUnlimitedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndiaUnlimitedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndiaUnlimitedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
