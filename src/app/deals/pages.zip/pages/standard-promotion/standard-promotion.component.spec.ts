import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StandardPromotionComponent } from './standard-promotion.component';

describe('DealViewComponent', () => {
  let component: StandardPromotionComponent;
  let fixture: ComponentFixture<StandardPromotionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StandardPromotionComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardPromotionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
